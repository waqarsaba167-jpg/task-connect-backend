require("dotenv").config();
const express = require("express");
const cors = require("cors");
const crypto = require("crypto");
const path = require("path");
const fs = require("fs");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const rateLimit = require("express-rate-limit");
const Database = require("better-sqlite3");

// =============================================================================
// CONFIG
// =============================================================================
const PORT = parseInt(process.env.PORT || "4000", 10);
const JWT_SECRET = process.env.JWT_SECRET || "dev-only-insecure-secret-change-me";
const DATABASE_PATH = process.env.DATABASE_PATH || "./data/tcg.db";
const ADMIN_API_KEY = process.env.ADMIN_API_KEY || "dev-only-insecure-admin-key";

// Each offerwall network's postback uses its own parameter names — verify
// the exact names against your publisher dashboard once approved.
const NETWORKS = {
  torox: {
    placementId: process.env.TOROX_PLACEMENT_ID,
    secret: process.env.TOROX_POSTBACK_SECRET,
    params: { userId: "subid", amount: "amount", txnId: "transaction_id", secret: "secret" },
  },
  adgate: {
    placementId: process.env.ADGATE_PLACEMENT_ID,
    secret: process.env.ADGATE_POSTBACK_SECRET,
    params: { userId: "subid", amount: "payout", txnId: "transaction_id", secret: "secret" },
  },
  cpx: {
    placementId: process.env.CPX_APP_ID,
    secret: process.env.CPX_POSTBACK_SECRET,
    params: { userId: "user_id", amount: "amount_local", txnId: "trans_id", secret: "secure_hash" },
  },
};

const AD_VIEW_CATEGORY = "Ad Views";
const VALID_CATEGORIES = ["Social", "Website Visits", "Ad Views", "Games"];

// =============================================================================
// DATABASE
// =============================================================================
const dbDir = path.dirname(DATABASE_PATH);
if (!fs.existsSync(dbDir)) fs.mkdirSync(dbDir, { recursive: true });

const db = new Database(DATABASE_PATH);
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    points INTEGER NOT NULL DEFAULT 0,
    referral_code TEXT UNIQUE NOT NULL,
    referred_by TEXT,
    status TEXT NOT NULL DEFAULT 'active', -- pending | active | banned
    role TEXT NOT NULL DEFAULT 'user',     -- user | admin
    photo TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS transactions (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id),
    type TEXT NOT NULL,
    network TEXT,
    external_txn_id TEXT,
    points INTEGER NOT NULL,
    status TEXT NOT NULL DEFAULT 'confirmed',
    meta TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(network, external_txn_id)
  );

  CREATE TABLE IF NOT EXISTS withdrawals (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id),
    amount_points INTEGER NOT NULL,
    amount_pkr INTEGER NOT NULL,
    gateway TEXT NOT NULL,
    account_number TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    decided_at TEXT
  );

  CREATE TABLE IF NOT EXISTS tasks (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    category TEXT NOT NULL,
    reward INTEGER NOT NULL,
    link TEXT,
    active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS task_completions (
    user_id TEXT NOT NULL REFERENCES users(id),
    task_id TEXT NOT NULL REFERENCES tasks(id),
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    PRIMARY KEY (user_id, task_id)
  );

  CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );

  CREATE INDEX IF NOT EXISTS idx_transactions_user ON transactions(user_id);
  CREATE INDEX IF NOT EXISTS idx_withdrawals_status ON withdrawals(status);
  CREATE INDEX IF NOT EXISTS idx_tasks_active ON tasks(active);
`);

const existingColumns = db.prepare("PRAGMA table_info(users)").all().map((c) => c.name);
if (!existingColumns.includes("role")) db.exec("ALTER TABLE users ADD COLUMN role TEXT NOT NULL DEFAULT 'user'");
if (!existingColumns.includes("photo")) db.exec("ALTER TABLE users ADD COLUMN photo TEXT");

// =============================================================================
// SETTINGS HELPERS
// =============================================================================
const SETTINGS_DEFAULTS = {
  pkrPerPoint: 2.0,
  minWithdrawalPoints: 100,
  dailyBonusPerDay: 10,
  adFrequencyMin: 2,
  announcement: "Welcome to Task Connect Global! Complete tasks daily to earn more.",
  paymentOptions: ["EasyPaisa", "JazzCash", "Bank Transfer", "PayPal", "Payeer", "Binance"],
  theme: "Purple",
};

function getAllSettings() {
  const rows = db.prepare("SELECT key, value FROM settings").all();
  const overrides = {};
  for (const row of rows) {
    try { overrides[row.key] = JSON.parse(row.value); } catch (e) { overrides[row.key] = row.value; }
  }
  return { ...SETTINGS_DEFAULTS, ...overrides };
}
function getSetting(key) { return getAllSettings()[key]; }
function setSettings(partial) {
  const upsert = db.prepare(`INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value`);
  const txn = db.transaction((entries) => {
    for (const [key, value] of entries) {
      if (!(key in SETTINGS_DEFAULTS)) continue;
      upsert.run(key, JSON.stringify(value));
    }
  });
  txn(Object.entries(partial));
  return getAllSettings();
}

// =============================================================================
// POINTS LEDGER — the only place a balance is ever allowed to change
// =============================================================================
function applyPointsChange({ userId, points, type, network = null, externalTxnId = null, status = "confirmed", meta = null }) {
  const txn = db.transaction(() => {
    if (network && externalTxnId) {
      const existing = db.prepare("SELECT id FROM transactions WHERE network = ? AND external_txn_id = ?").get(network, externalTxnId);
      if (existing) return { duplicate: true };
    }
    const user = db.prepare("SELECT points FROM users WHERE id = ?").get(userId);
    if (!user) throw new Error("User not found");
    const newBalance = user.points + points;
    if (newBalance < 0) throw new Error("Insufficient points balance");
    db.prepare("UPDATE users SET points = ? WHERE id = ?").run(newBalance, userId);
    db.prepare(
      `INSERT INTO transactions (id, user_id, type, network, external_txn_id, points, status, meta) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(crypto.randomUUID(), userId, type, network, externalTxnId, points, status, meta ? JSON.stringify(meta) : null);
    return { newBalance };
  });
  return txn();
}
function pointsToPkr(points) { return Math.round(points * getSetting("pkrPerPoint")); }

// =============================================================================
// MIDDLEWARE
// =============================================================================
function requireAuth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: "Missing Authorization header" });
  try {
    req.userId = jwt.verify(token, JWT_SECRET).userId;
    next();
  } catch (e) {
    return res.status(401).json({ error: "Invalid or expired token" });
  }
}

function requireAdminRole(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: "Missing Authorization header" });
  let payload;
  try { payload = jwt.verify(token, JWT_SECRET); } catch (e) { return res.status(401).json({ error: "Invalid or expired token" }); }
  const user = db.prepare("SELECT role, status FROM users WHERE id = ?").get(payload.userId);
  if (!user) return res.status(401).json({ error: "User not found" });
  if (user.status === "banned") return res.status(403).json({ error: "This account has been suspended" });
  if (user.role !== "admin") return res.status(403).json({ error: "Admin access required" });
  req.userId = payload.userId;
  next();
}

// BOOTSTRAP-ONLY key check — see the /admin/bootstrap-promote route below.
function requireBootstrapKey(req, res, next) {
  const key = req.headers["x-admin-key"] || req.query.key;
  if (!key || key !== ADMIN_API_KEY) return res.status(401).json({ error: "Invalid bootstrap key" });
  next();
}

// =============================================================================
// APP
// =============================================================================
const app = express();
app.use(cors());
app.use(express.json({ limit: "3mb" })); // photo uploads are base64 data URLs

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 20, message: { error: "Too many attempts — try again later." } });

app.get("/health", (req, res) => res.json({ ok: true }));

// ---------- Auth ----------
function generateReferralCode() { return "TCG-" + crypto.randomBytes(4).toString("hex").toUpperCase(); }
function signToken(userId) { return jwt.sign({ userId }, JWT_SECRET, { expiresIn: "30d" }); }
function publicUser(u) {
  return { id: u.id, name: u.name, email: u.email, points: u.points, referralCode: u.referral_code, status: u.status, role: u.role, photo: u.photo, createdAt: u.created_at };
}

app.post("/auth/register", authLimiter, async (req, res) => {
  const { name, email, password, referralCode } = req.body || {};
  if (!name || !email || !password) return res.status(400).json({ error: "name, email, and password are required" });
  if (password.length < 8) return res.status(400).json({ error: "Password must be at least 8 characters" });

  const existing = db.prepare("SELECT id FROM users WHERE email = ?").get(email.toLowerCase());
  if (existing) return res.status(409).json({ error: "An account with that email already exists" });

  let referredBy = null;
  if (referralCode) {
    const referrer = db.prepare("SELECT id FROM users WHERE referral_code = ?").get(referralCode);
    if (referrer) referredBy = referrer.id;
  }

  const passwordHash = await bcrypt.hash(password, 12);
  const id = crypto.randomUUID();
  db.prepare(
    `INSERT INTO users (id, name, email, password_hash, points, referral_code, referred_by, status) VALUES (?, ?, ?, ?, 0, ?, ?, 'pending')`
  ).run(id, name, email.toLowerCase(), passwordHash, generateReferralCode(), referredBy);

  const user = db.prepare("SELECT * FROM users WHERE id = ?").get(id);
  res.status(201).json({ user: publicUser(user), pendingApproval: true });
});

app.post("/auth/login", authLimiter, async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: "email and password are required" });

  const user = db.prepare("SELECT * FROM users WHERE email = ?").get(email.toLowerCase());
  if (!user) return res.status(401).json({ error: "Invalid email or password" });
  if (user.status === "banned") return res.status(403).json({ error: "This account has been suspended" });
  if (user.status === "pending") return res.status(403).json({ error: "Your account is awaiting admin approval" });

  const valid = await bcrypt.compare(password, user.password_hash);
  if (!valid) return res.status(401).json({ error: "Invalid email or password" });

  res.json({ token: signToken(user.id), user: publicUser(user) });
});

// ---------- User ----------
app.get("/user/me", requireAuth, (req, res) => {
  const user = db.prepare("SELECT * FROM users WHERE id = ?").get(req.userId);
  if (!user) return res.status(404).json({ error: "User not found" });
  res.json({
    id: user.id, name: user.name, email: user.email, points: user.points,
    pkrEquivalent: pointsToPkr(user.points), referralCode: user.referral_code,
    status: user.status, role: user.role, photo: user.photo, createdAt: user.created_at,
  });
});

const MAX_PHOTO_DATA_URL_LENGTH = 2_000_000;
app.put("/user/photo", requireAuth, (req, res) => {
  const { photo } = req.body || {};
  if (photo !== null && typeof photo !== "string") return res.status(400).json({ error: "photo must be a data URL string or null" });
  if (photo && !photo.startsWith("data:image/")) return res.status(400).json({ error: "photo must be an image data URL" });
  if (photo && photo.length > MAX_PHOTO_DATA_URL_LENGTH) return res.status(413).json({ error: "That image is too large — please choose a smaller photo" });
  db.prepare("UPDATE users SET photo = ? WHERE id = ?").run(photo, req.userId);
  res.json({ photo });
});

app.get("/user/transactions", requireAuth, (req, res) => {
  const rows = db.prepare("SELECT id, type, network, points, status, created_at FROM transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 100").all(req.userId);
  res.json({ transactions: rows });
});

app.get("/user/offerwall-link/:network", requireAuth, (req, res) => {
  const network = req.params.network;
  const net = NETWORKS[network];
  if (!net) return res.status(404).json({ error: `Unknown network "${network}"` });
  if (!net.placementId) return res.status(503).json({ error: `${network} is not configured yet` });
  let url;
  if (network === "torox") url = `https://torox.io/ifr/show/${net.placementId}/${req.userId}`;
  else if (network === "adgate") url = `https://wall.adgaterewards.com/${net.placementId}?subid=${req.userId}`;
  else if (network === "cpx") url = `https://offers.cpx-research.com/index.php?app_id=${net.placementId}&ext_user_id=${req.userId}`;
  res.json({ url });
});

// ---------- Settings ----------
app.get("/settings", requireAuth, (req, res) => res.json(getAllSettings()));
app.put("/settings", requireAdminRole, (req, res) => res.json(setSettings(req.body || {})));

// ---------- Tasks ----------
app.get("/tasks", requireAuth, (req, res) => {
  const rows = db.prepare(
    `SELECT t.*, (tc.user_id IS NOT NULL) as completed FROM tasks t
     LEFT JOIN task_completions tc ON tc.task_id = t.id AND tc.user_id = ?
     WHERE t.active = 1 ORDER BY t.created_at DESC`
  ).all(req.userId);
  res.json({ tasks: rows.map((r) => ({ ...r, completed: !!r.completed })) });
});

app.post("/tasks", requireAdminRole, (req, res) => {
  const { title, category, reward, link } = req.body || {};
  if (!title || !category || !reward) return res.status(400).json({ error: "title, category, and reward are required" });
  if (!VALID_CATEGORIES.includes(category)) return res.status(400).json({ error: `category must be one of: ${VALID_CATEGORIES.join(", ")}` });
  if (category === "Website Visits" && !link) return res.status(400).json({ error: "Website Visits tasks require a link" });

  const id = crypto.randomUUID();
  db.prepare(`INSERT INTO tasks (id, title, category, reward, link, active) VALUES (?, ?, ?, ?, ?, 1)`).run(id, title, category, parseInt(reward, 10), link || null);
  res.status(201).json({ task: db.prepare("SELECT * FROM tasks WHERE id = ?").get(id) });
});

app.put("/tasks/:id", requireAdminRole, (req, res) => {
  const existing = db.prepare("SELECT * FROM tasks WHERE id = ?").get(req.params.id);
  if (!existing) return res.status(404).json({ error: "Task not found" });
  const { title, category, reward, link } = req.body || {};
  if (category && !VALID_CATEGORIES.includes(category)) return res.status(400).json({ error: `category must be one of: ${VALID_CATEGORIES.join(", ")}` });
  db.prepare(`UPDATE tasks SET title = ?, category = ?, reward = ?, link = ? WHERE id = ?`).run(
    title ?? existing.title, category ?? existing.category, reward ? parseInt(reward, 10) : existing.reward, link !== undefined ? link : existing.link, req.params.id
  );
  res.json({ task: db.prepare("SELECT * FROM tasks WHERE id = ?").get(req.params.id) });
});

app.delete("/tasks/:id", requireAdminRole, (req, res) => {
  const result = db.prepare("UPDATE tasks SET active = 0 WHERE id = ?").run(req.params.id);
  if (result.changes === 0) return res.status(404).json({ error: "Task not found" });
  res.json({ removed: true });
});

// ---------- Rewards (daily bonus / ad view / task proof) ----------
app.post("/rewards/claim", requireAuth, (req, res) => {
  const { type, day, taskId } = req.body || {};

  if (type === "daily_bonus") {
    const perDay = getSetting("dailyBonusPerDay");
    const streakDay = Math.min(7, Math.max(1, parseInt(day, 10) || 1));
    const points = perDay * streakDay;
    try {
      const result = applyPointsChange({ userId: req.userId, points, type, meta: { day: streakDay } });
      return res.json({ pointsAwarded: points, newBalance: result.newBalance });
    } catch (e) { return res.status(400).json({ error: e.message }); }
  }

  if (type === "ad_view" || type === "task_proof") {
    if (!taskId) return res.status(400).json({ error: "taskId is required for this reward type" });
    const task = db.prepare("SELECT * FROM tasks WHERE id = ? AND active = 1").get(taskId);
    if (!task) return res.status(404).json({ error: "That task no longer exists or is no longer active" });

    const alreadyDone = db.prepare("SELECT 1 FROM task_completions WHERE user_id = ? AND task_id = ?").get(req.userId, taskId);
    if (alreadyDone) return res.status(409).json({ error: "You've already completed this task" });

    const isAdCategory = task.category === AD_VIEW_CATEGORY;
    if (type === "ad_view" && !isAdCategory) return res.status(400).json({ error: "That task isn't an Ad Views task" });
    if (type === "task_proof" && isAdCategory) return res.status(400).json({ error: "Ad Views tasks should use the ad_view reward type" });

    try {
      const result = applyPointsChange({ userId: req.userId, points: task.reward, type, meta: { taskId: task.id, taskTitle: task.title } });
      db.prepare("INSERT INTO task_completions (user_id, task_id) VALUES (?, ?)").run(req.userId, taskId);
      return res.json({ pointsAwarded: task.reward, newBalance: result.newBalance });
    } catch (e) { return res.status(400).json({ error: e.message }); }
  }

  return res.status(400).json({ error: `Unknown reward type "${type}"` });
});

// ---------- Wallet ----------
app.post("/wallet/withdraw", requireAuth, (req, res) => {
  const { gateway, accountNumber, amountPoints } = req.body || {};
  if (!gateway || !accountNumber || !amountPoints) return res.status(400).json({ error: "gateway, accountNumber, and amountPoints are required" });
  const points = parseInt(amountPoints, 10);
  if (!Number.isFinite(points) || points <= 0) return res.status(400).json({ error: "amountPoints must be a positive number" });
  const minWithdrawalPoints = getSetting("minWithdrawalPoints");
  if (points < minWithdrawalPoints) return res.status(400).json({ error: `Minimum withdrawal is ${minWithdrawalPoints} points` });

  try {
    applyPointsChange({ userId: req.userId, points: -points, type: "withdrawal", status: "pending" });
  } catch (e) { return res.status(400).json({ error: e.message }); }

  const id = crypto.randomUUID();
  db.prepare(`INSERT INTO withdrawals (id, user_id, amount_points, amount_pkr, gateway, account_number, status) VALUES (?, ?, ?, ?, ?, ?, 'pending')`)
    .run(id, req.userId, points, pointsToPkr(points), gateway, accountNumber);
  res.status(201).json({ id, status: "pending" });
});

app.get("/wallet/withdrawals", requireAuth, (req, res) => {
  const rows = db.prepare("SELECT id, amount_points, amount_pkr, gateway, status, created_at FROM withdrawals WHERE user_id = ? ORDER BY created_at DESC").all(req.userId);
  res.json({ withdrawals: rows });
});

// ---------- Offerwall postbacks (called by the networks, not the frontend) ----------
app.get("/postback/:network", (req, res) => {
  const networkName = req.params.network;
  const net = NETWORKS[networkName];
  if (!net) return res.status(404).send("unknown network");
  if (!net.secret) return res.status(503).send("network not configured");

  const { userId: userIdParam, amount: amountParam, txnId: txnIdParam, secret: secretParam } = net.params;
  if (req.query[secretParam] !== net.secret) return res.status(403).send("invalid secret");

  const userId = req.query[userIdParam];
  const rawAmount = req.query[amountParam];
  const externalTxnId = req.query[txnIdParam];
  if (!userId || !rawAmount || !externalTxnId) return res.status(400).send("missing required parameters");

  const user = db.prepare("SELECT id, status FROM users WHERE id = ?").get(userId);
  if (!user) { console.warn(`[postback:${networkName}] unknown user_id "${userId}"`); return res.status(200).send("1"); }
  if (user.status === "banned") { console.warn(`[postback:${networkName}] ignoring credit for banned user "${userId}"`); return res.status(200).send("1"); }

  const points = Math.round(parseFloat(rawAmount));
  if (!Number.isFinite(points) || points <= 0) return res.status(400).send("invalid amount");

  try {
    const result = applyPointsChange({ userId, points, type: "offerwall_credit", network: networkName, externalTxnId: String(externalTxnId), meta: req.query });
    if (result.duplicate) return res.status(200).send("1");
    console.log(`[postback:${networkName}] credited ${points} pts to user ${userId} (txn ${externalTxnId})`);
    return res.status(200).send("1");
  } catch (e) {
    console.error(`[postback:${networkName}] failed:`, e.message);
    return res.status(500).send("0");
  }
});

// ---------- Admin ----------

// ONE-TIME bootstrap: promotes + activates a user using the static key,
// since no admin exists the first time this runs. Accepts the key as a
// header OR a ?key= query param, specifically so it can be triggered by
// just visiting a URL in a mobile browser (no REST-client app required).
// Rotate ADMIN_API_KEY in your Render dashboard after using this once.
app.post("/admin/bootstrap-promote/:userId", requireBootstrapKey, (req, res) => {
  const result = db.prepare("UPDATE users SET role = 'admin', status = 'active' WHERE id = ?").run(req.params.userId);
  if (result.changes === 0) return res.status(404).json({ error: "User not found" });
  res.json({ promoted: true });
});
// GET version of the same thing, purely so it can be triggered by tapping a
// link on a phone (browsers can't easily send a POST by just visiting a URL).
app.get("/admin/bootstrap-promote/:userId", requireBootstrapKey, (req, res) => {
  const result = db.prepare("UPDATE users SET role = 'admin', status = 'active' WHERE id = ?").run(req.params.userId);
  if (result.changes === 0) return res.status(404).json({ error: "User not found" });
  res.json({ promoted: true });
});

const adminRouter = express.Router();
adminRouter.use(requireAdminRole);

adminRouter.get("/users", (req, res) => {
  const status = req.query.status;
  const rows = status
    ? db.prepare("SELECT id, name, email, points, status, role, created_at FROM users WHERE status = ? ORDER BY created_at DESC").all(status)
    : db.prepare("SELECT id, name, email, points, status, role, created_at FROM users ORDER BY created_at DESC LIMIT 200").all();
  res.json({ users: rows });
});
adminRouter.post("/users/:id/approve", (req, res) => {
  const result = db.prepare("UPDATE users SET status = 'active' WHERE id = ? AND status = 'pending'").run(req.params.id);
  if (result.changes === 0) return res.status(404).json({ error: "No pending user with that id" });
  res.json({ status: "active" });
});
adminRouter.post("/users/:id/reject", (req, res) => {
  const result = db.prepare("DELETE FROM users WHERE id = ? AND status = 'pending'").run(req.params.id);
  if (result.changes === 0) return res.status(404).json({ error: "No pending user with that id" });
  res.json({ removed: true });
});
adminRouter.post("/users/:id/ban", (req, res) => { db.prepare("UPDATE users SET status = 'banned' WHERE id = ?").run(req.params.id); res.json({ status: "banned" }); });
adminRouter.post("/users/:id/unban", (req, res) => { db.prepare("UPDATE users SET status = 'active' WHERE id = ?").run(req.params.id); res.json({ status: "active" }); });
adminRouter.delete("/users/:id", (req, res) => {
  const target = db.prepare("SELECT role FROM users WHERE id = ?").get(req.params.id);
  if (!target) return res.status(404).json({ error: "User not found" });
  if (target.role === "admin") return res.status(400).json({ error: "Can't remove an admin account this way" });
  db.prepare("DELETE FROM users WHERE id = ?").run(req.params.id);
  res.json({ removed: true });
});

adminRouter.get("/withdrawals", (req, res) => {
  const status = req.query.status || "pending";
  const rows = db.prepare(
    `SELECT w.id, w.amount_points, w.amount_pkr, w.gateway, w.account_number, w.status, w.created_at, u.name as user_name, u.email as user_email
     FROM withdrawals w JOIN users u ON u.id = w.user_id WHERE w.status = ? ORDER BY w.created_at ASC`
  ).all(status);
  res.json({ withdrawals: rows });
});
adminRouter.post("/withdrawals/:id/approve", (req, res) => {
  const w = db.prepare("SELECT * FROM withdrawals WHERE id = ?").get(req.params.id);
  if (!w) return res.status(404).json({ error: "Withdrawal not found" });
  if (w.status !== "pending") return res.status(400).json({ error: "Already decided" });
  db.prepare("UPDATE withdrawals SET status = 'approved', decided_at = datetime('now') WHERE id = ?").run(w.id);
  res.json({ status: "approved" });
});
adminRouter.post("/withdrawals/:id/reject", (req, res) => {
  const w = db.prepare("SELECT * FROM withdrawals WHERE id = ?").get(req.params.id);
  if (!w) return res.status(404).json({ error: "Withdrawal not found" });
  if (w.status !== "pending") return res.status(400).json({ error: "Already decided" });
  db.prepare("UPDATE withdrawals SET status = 'rejected', decided_at = datetime('now') WHERE id = ?").run(w.id);
  applyPointsChange({ userId: w.user_id, points: w.amount_points, type: "admin_adjustment", meta: { reason: "withdrawal_rejected_refund", withdrawalId: w.id } });
  res.json({ status: "rejected", refunded: w.amount_points });
});

adminRouter.get("/networks", (req, res) => {
  const networks = Object.entries(NETWORKS).map(([key, net]) => ({ key, configured: Boolean(net.placementId && net.secret) }));
  res.json({ networks });
});

app.use("/admin", adminRouter);

app.use((req, res) => res.status(404).json({ error: "Not found" }));
app.use((err, req, res, next) => { console.error(err); res.status(500).json({ error: "Internal server error" }); });

app.listen(PORT, () => console.log(`Task Connect Global backend listening on port ${PORT}`));
